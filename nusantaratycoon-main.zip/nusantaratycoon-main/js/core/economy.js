/*
 * Aturan ekonomi game. Semua fungsi murni terhadap `state` dan `now` (milidetik),
 * tanpa DOM. Nanti fungsi-fungsi yang mengubah data (collect, sell, upgrade, unlock)
 * bisa dipindah ke Postgres function / Edge Function di Supabase agar tidak bisa dicurangi.
 *
 * Fungsi yang mengubah data mengembalikan { ok: true, ... } atau { ok: false, reason }.
 */
(function (NT) {
  const C = NT.config;
  const D = NT.data;
  const fmt = NT.fmt;

  const fail = function (reason) { return { ok: false, reason: reason }; };

  /* ---------- Util ---------- */

  // Jarak rute laut antar hub pelabuhan (km): garis lurus (haversine) x faktor kelokan rute.
  function distanceKm(a, b) {
    if (a === b) return 0;
    const ha = D.regions[a].hub, hb = D.regions[b].hub;
    const rad = Math.PI / 180;
    const dLat = (hb.lat - ha.lat) * rad, dLon = (hb.lon - ha.lon) * rad;
    const h = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(ha.lat * rad) * Math.cos(hb.lat * rad) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return 6371 * 2 * Math.asin(Math.sqrt(h)) * C.routeDetour;
  }

  function hashString(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 100000;
    return h / 100000 * Math.PI * 2;
  }

  function buildingLevel(state, id) {
    return (state.buildings[id] && state.buildings[id].level) || 0;
  }

  function infraLevel(state, regionId, infraId) {
    const r = state.regions[regionId];
    return (r && r.infra && r.infra[infraId]) || 0;
  }

  /* ---------- Produksi (dihitung dari timestamp, tetap jalan saat offline) ---------- */

  // Pengali dunia nyata (musim dan peristiwa) untuk sebuah bangunan pada waktu `now`.
  function worldProdMult(buildingId, now) {
    if (now == null) return 1;
    const b = D.buildings[buildingId];
    return NT.world.seasonProd(b.produces, now) * NT.world.eventProd(b, now);
  }

  // Unit per menit. `now` opsional: tanpa `now`, musim dan peristiwa tidak dihitung.
  function productionRate(state, buildingId, now) {
    const b = D.buildings[buildingId];
    const lvl = buildingLevel(state, buildingId);
    if (!lvl) return 0;
    const tol = infraLevel(state, b.region, 'tol');
    return b.baseRate * lvl * (1 + C.tolBonusPerLevel * tol) * worldProdMult(buildingId, now);
  }

  function capacity(state, buildingId, now) {
    return Math.floor(productionRate(state, buildingId, now) * 60 * C.storageHours);
  }

  // Hasil tertunda memakai laju saat ini untuk seluruh jendela (gudang hanya beberapa jam, jadi selisihnya kecil).
  function pending(state, buildingId, now) {
    const sb = state.buildings[buildingId];
    if (!sb || !sb.level) return 0;
    const minutes = Math.max(0, (now - sb.lastCollected) / 60000);
    return Math.min(capacity(state, buildingId, now), productionRate(state, buildingId, now) * minutes);
  }

  // Penghitung statistik (untuk panduan, pencapaian, dan halaman Capaian).
  function stat(state, key, n) {
    if (!state.stats) state.stats = {};
    state.stats[key] = (state.stats[key] || 0) + n;
  }

  // Pengumpulan murni tanpa statistik: dipakai internal (mis. sebelum upgrade mengubah laju produksi).
  function gather(state, buildingId, now) {
    const b = D.buildings[buildingId];
    const sb = state.buildings[buildingId];
    if (!b || !sb) return fail('Bangunan belum dibangun.');
    const p = pending(state, buildingId, now);
    const whole = Math.floor(p);
    if (whole < 1) return fail('Belum ada hasil yang bisa dikumpulkan.');

    const rate = productionRate(state, buildingId, now);
    const isFull = p >= capacity(state, buildingId, now);
    state.inventory[b.produces] = (state.inventory[b.produces] || 0) + whole;
    // Sisa pecahan tetap dihitung, kecuali gudang sudah penuh.
    sb.lastCollected = isFull ? now : now - ((p - whole) / rate) * 60000;
    return { ok: true, commodity: b.produces, amount: whole };
  }

  function collect(state, buildingId, now) {
    const res = gather(state, buildingId, now);
    if (res.ok) { stat(state, 'collects', 1); stat(state, 'produced', res.amount); }
    return res;
  }

  function collectAll(state, now) {
    const items = {};
    let total = 0;
    Object.keys(state.buildings).forEach(function (id) {
      const res = collect(state, id, now);
      if (res.ok) {
        items[res.commodity] = (items[res.commodity] || 0) + res.amount;
        total += res.amount;
      }
    });
    if (!total) return fail('Belum ada hasil yang bisa dikumpulkan.');
    return { ok: true, items: items, total: total };
  }

  function totalPendingValue(state, now) {
    let v = 0;
    Object.keys(state.buildings).forEach(function (id) {
      v += pending(state, id, now) * D.commodities[D.buildings[id].produces].basePrice;
    });
    return v;
  }

  /* ---------- Biaya dan upgrade ---------- */

  function buildingCost(buildingId, currentLevel) {
    return Math.round(D.buildings[buildingId].baseCost * Math.pow(C.upgradeGrowth, currentLevel));
  }

  function infraCost(regionId, infraId, currentLevel) {
    const f = D.regions[regionId].infraCostFactor || 1;
    return Math.round(D.infra[infraId].baseCost * f * Math.pow(C.upgradeGrowth, currentLevel));
  }

  /* ---------- Waktu pembangunan (timer) ---------- */

  function jobsOf(state) { return state.jobs || (state.jobs = []); }

  function jobFor(state, key) {
    return jobsOf(state).filter(function (j) { return j.key === key; })[0] || null;
  }

  // Pertumbuhan durasi: x`early` tiap level sampai level `lateFromLevel`, sesudah itu x`late` tiap level.
  function growth(level, early, late) {
    const a = Math.min(level, C.lateFromLevel), b = Math.max(0, level - C.lateFromLevel);
    return Math.pow(early, a) * Math.pow(late, b);
  }
  function capDuration(sec) { return Math.min(sec, C.maxDurationHours * 3600); }

  // Makin tinggi level makin lama (dan makin curam setelah level 2). Bangunan mahal dan wilayah mahal ikut lebih lama. Hasil dalam milidetik.
  function buildDuration(buildingId, level) {
    if (!C.buildTimeEnabled) return 0;
    const tier = Math.pow(D.buildings[buildingId].baseCost / 60, C.buildTierExp);
    return Math.round(capDuration(C.buildBaseSec * tier * growth(level, C.buildGrowth, C.buildGrowthLate))) * 1000;
  }

  function infraDuration(regionId, level) {
    if (!C.buildTimeEnabled) return 0;
    const f = Math.pow(D.regions[regionId].infraCostFactor || 1, C.infraRegionExp);
    return Math.round(capDuration(C.infraBaseSec * f * growth(level, C.infraGrowth, C.infraGrowthLate))) * 1000;
  }

  // Pindahkan hasil tertunda bangunan `ids` ke gudang pada waktu `at`, jalankan `change` (mengubah laju
  // produksi), lalu pertahankan sisa pecahan agar tidak ikut dikali laju baru secara surut.
  function rebase(state, ids, at, change) {
    const snap = ids.filter(function (id) { return state.buildings[id]; }).map(function (id) {
      const p = pending(state, id, at);
      const whole = Math.floor(p);
      const cid = D.buildings[id].produces;
      state.inventory[cid] = (state.inventory[cid] || 0) + whole;
      return { id: id, frac: p >= capacity(state, id, at) ? 0 : p - whole };
    });
    change();
    snap.forEach(function (x) {
      const rate = productionRate(state, x.id, at);
      state.buildings[x.id].lastCollected = at - (rate ? x.frac / rate * 60000 : 0);
    });
  }

  // Terapkan hasil pembangunan yang selesai pada waktu job.endsAt (aman dipanggil belakangan, mis. setelah offline).
  function applyJob(state, j) {
    if (j.kind === 'building') {
      if (!state.buildings[j.id]) {
        state.buildings[j.id] = { level: 1, lastCollected: j.endsAt };
      } else {
        rebase(state, [j.id], j.endsAt, function () { state.buildings[j.id].level = j.to; });
      }
    } else if (j.id === 'tol') {
      rebase(state, D.regions[j.region].buildings, j.endsAt, function () { state.regions[j.region].infra.tol = j.to; });
    } else {
      state.regions[j.region].infra[j.id] = j.to;
    }
  }

  // Selesaikan semua pembangunan yang waktunya habis. Mengembalikan daftar job yang selesai.
  function settle(state, now) {
    const list = jobsOf(state);
    const done = list.filter(function (j) { return j.endsAt <= now; })
      .sort(function (a, b) { return a.endsAt - b.endsAt; });
    if (!done.length) return [];
    state.jobs = list.filter(function (j) { return j.endsAt > now; });
    done.forEach(function (j) { applyJob(state, j); });
    return done;
  }

  function speedupCost(job, now) {
    const total = Math.max(1, job.endsAt - job.startedAt);
    const left = Math.max(0, job.endsAt - now);
    return Math.max(1, Math.ceil(job.cost * C.speedupCostShare * left / total));
  }

  function speedup(state, key, now) {
    const job = jobFor(state, key);
    if (!job) return fail('Pembangunan sudah selesai.');
    const cost = speedupCost(job, now);
    if (state.cash < cost) return fail('Kas belum cukup untuk mempercepat.');
    state.cash -= cost;
    job.endsAt = now;
    settle(state, now);
    return { ok: true, cost: cost, finished: job };
  }

  function builderCheck(state) {
    if (jobsOf(state).length >= C.maxBuilders) {
      return fail('Semua tukang sedang sibuk (' + C.maxBuilders + '). Tunggu salah satu selesai atau percepat.');
    }
    return null;
  }

  function upgradeBuilding(state, buildingId, now) {
    const b = D.buildings[buildingId];
    if (!b) return fail('Bangunan tidak dikenal.');
    if (!state.regions[b.region] || !state.regions[b.region].unlocked) return fail('Wilayah belum dibuka.');

    const key = 'b:' + buildingId;
    if (jobFor(state, key)) return fail('Sedang dalam pembangunan.');
    const lvl = buildingLevel(state, buildingId);
    const cost = buildingCost(buildingId, lvl);
    if (state.cash < cost) return fail('Kas belum cukup.');

    const dur = buildDuration(buildingId, lvl);
    if (dur > 0) {
      const busy = builderCheck(state);
      if (busy) return busy;
      state.cash -= cost;
      jobsOf(state).push({ key: key, kind: 'building', id: buildingId, region: b.region, from: lvl, to: lvl + 1, startedAt: now, endsAt: now + dur, cost: cost });
      stat(state, lvl === 0 ? 'builds' : 'upgrades', 1);
      return { ok: true, cost: cost, level: lvl + 1, built: lvl === 0, queued: true, durationMs: dur };
    }

    gather(state, buildingId, now); // amankan hasil sebelum laju produksi berubah
    state.cash -= cost;
    if (lvl === 0) {
      state.buildings[buildingId] = { level: 1, lastCollected: now };
    } else {
      state.buildings[buildingId].level = lvl + 1;
    }
    stat(state, lvl === 0 ? 'builds' : 'upgrades', 1);
    return { ok: true, cost: cost, level: lvl + 1, built: lvl === 0 };
  }

  function upgradeInfra(state, regionId, infraId, now) {
    const infra = D.infra[infraId];
    const rs = state.regions[regionId];
    if (!infra || !rs) return fail('Infrastruktur tidak dikenal.');
    if (!rs.unlocked) return fail('Wilayah belum dibuka.');

    const key = 'i:' + regionId + ':' + infraId;
    if (jobFor(state, key)) return fail('Sedang dalam pembangunan.');
    const lvl = infraLevel(state, regionId, infraId);
    if (lvl >= infra.maxLevel) return fail('Sudah level maksimum.');
    const cost = infraCost(regionId, infraId, lvl);
    if (state.cash < cost) return fail('Kas belum cukup.');

    const dur = infraDuration(regionId, lvl);
    if (dur > 0) {
      const busy = builderCheck(state);
      if (busy) return busy;
      state.cash -= cost;
      jobsOf(state).push({ key: key, kind: 'infra', id: infraId, region: regionId, from: lvl, to: lvl + 1, startedAt: now, endsAt: now + dur, cost: cost });
      stat(state, 'upgrades', 1);
      return { ok: true, cost: cost, level: lvl + 1, queued: true, durationMs: dur };
    }

    // Tol mengubah laju produksi, jadi amankan hasil semua bangunan di wilayah ini dulu.
    if (infraId === 'tol') {
      D.regions[regionId].buildings.forEach(function (bid) { gather(state, bid, now); });
    }
    state.cash -= cost;
    rs.infra[infraId] = lvl + 1;
    stat(state, 'upgrades', 1);
    return { ok: true, cost: cost, level: lvl + 1 };
  }

  // Perkiraan pemasukan per menit (nilai dasar semua hasil produksi, belum dikurangi ongkir).
  function incomePerMin(state, now) {
    let v = 0;
    Object.keys(state.buildings).forEach(function (id) {
      v += productionRate(state, id, now) * D.commodities[D.buildings[id].produces].basePrice;
    });
    return v;
  }

  // Semua pembelian yang mungkin saat ini: bangun/naikkan bangunan, infrastruktur, dan (opsional) buka wilayah.
  function candidates(state, includeUnlock) {
    const list = [];
    Object.keys(D.regions).forEach(function (rid) {
      const r = D.regions[rid], rs = state.regions[rid];
      if (!rs || r.comingSoon) return;
      if (!rs.unlocked) {
        if (includeUnlock) list.push({ cost: r.unlockCost, label: 'Buka ' + r.name, icon: '🔓', kind: 'unlock', id: rid, region: rid });
        return;
      }
      r.buildings.forEach(function (bid) {
        if (jobFor(state, 'b:' + bid)) return;
        const lvl = buildingLevel(state, bid);
        list.push({ cost: buildingCost(bid, lvl), icon: D.buildings[bid].icon, kind: 'building', id: bid, region: rid,
          label: (lvl ? 'Naikkan ' : 'Bangun ') + D.buildings[bid].name + (lvl ? ' ke Lv ' + (lvl + 1) : '') });
      });
      Object.keys(D.infra).forEach(function (iid) {
        if (jobFor(state, 'i:' + rid + ':' + iid)) return;
        const lvl = infraLevel(state, rid, iid);
        if (lvl >= D.infra[iid].maxLevel) return;
        list.push({ cost: infraCost(rid, iid, lvl), icon: D.infra[iid].icon, kind: 'infra', id: iid, region: rid,
          label: D.infra[iid].name + ' ' + r.name + ' Lv ' + (lvl + 1) });
      });
    });
    return list;
  }

  function cheapest(list) {
    return list.reduce(function (best, c) { return !best || c.cost < best.cost ? c : best; }, null);
  }

  // Target termurah berikutnya, supaya pemain selalu punya tujuan dekat.
  function nextGoal(state) { return cheapest(candidates(state, true)); }

  // Upgrade (bangunan atau infrastruktur) termurah; dipakai tombol "Upgrade termurah".
  function cheapestUpgrade(state) { return cheapest(candidates(state, false)); }

  function unlockRegion(state, regionId) {
    const r = D.regions[regionId];
    const rs = state.regions[regionId];
    if (!r || !rs || r.comingSoon) return fail('Wilayah ini belum tersedia.');
    if (rs.unlocked) return fail('Wilayah sudah terbuka.');
    if (state.cash < r.unlockCost) return fail('Kas belum cukup.');
    state.cash -= r.unlockCost;
    rs.unlocked = true;
    stat(state, 'unlocks', 1);
    return { ok: true, cost: r.unlockCost };
  }

  /* ---------- Pasar ---------- */

  // Tekanan pasokan: naik saat pemain menjual, meluruh seiring waktu.
  function marketStock(state, regionId, commodityId, now) {
    const m = state.market[regionId] && state.market[regionId][commodityId];
    if (!m) return 0;
    const minutes = Math.max(0, (now - m.updatedAt) / 60000);
    return m.stock * Math.exp(-C.marketDecayPerMin * minutes);
  }

  function wave(regionId, commodityId, now) {
    return 1 + C.priceWaveAmplitude * Math.sin(now / (7 * 60000) + hashString(regionId + commodityId));
  }

  // Pengali musim dan peristiwa terhadap harga komoditas (sama di semua pasar).
  function worldPriceMult(commodityId, now) {
    return NT.world.seasonPrice(commodityId, now) * NT.world.eventPrice(commodityId, now);
  }

  // Harga normal (tanpa fluktuasi dan tanpa tekanan pasokan).
  function normalPrice(regionId, commodityId) {
    const demand = (D.regions[regionId].demand && D.regions[regionId].demand[commodityId]) || 1;
    return D.commodities[commodityId].basePrice * demand;
  }

  function unitPrice(regionId, commodityId, stock, now) {
    const depth = D.commodities[commodityId].marketDepth;
    const pressure = stock / (stock + depth);
    return normalPrice(regionId, commodityId) * wave(regionId, commodityId, now) *
      worldPriceMult(commodityId, now) * (1 - C.maxMarketDrop * pressure);
  }

  function currentPrice(state, regionId, commodityId, now) {
    return unitPrice(regionId, commodityId, marketStock(state, regionId, commodityId, now), now);
  }

  // Ongkir per unit dari wilayah asal komoditas ke pasar tujuan:
  // bobot (kg) x jarak (km) x tarif kapal, lalu dikecilkan oleh pelabuhan. Barang curah murah (padi)
  // jadi paling terasa ongkirnya; barang bernilai tinggi (cengkeh, batik) hampir tidak.
  function shippingPerUnit(state, commodityId, marketId) {
    const c = D.commodities[commodityId];
    const km = distanceKm(c.region, marketId);
    if (!km) return 0;
    const ports = infraLevel(state, c.region, 'pelabuhan') + infraLevel(state, marketId, 'pelabuhan');
    const discount = Math.min(C.maxShippingDiscount, ports * C.portDiscountPerLevel);
    // freightFactor < 1 untuk muatan curah raksasa (batubara memakai kapal tongkang/bulk carrier, jauh lebih murah per kg).
    const realRp = c.unitKg * km * C.seaFreightRpPerKgKm * (c.freightFactor || 1);
    return realRp / C.priceScale * (1 - discount);
  }

  // Harga bersih per unit saat ini (harga pasar dikurangi ongkir).
  function netUnitPrice(state, commodityId, marketId, now) {
    return currentPrice(state, marketId, commodityId, now) - shippingPerUnit(state, commodityId, marketId);
  }

  function quoteSale(state, commodityId, marketId, qty, now) {
    let stock = marketStock(state, marketId, commodityId, now);
    let revenue = 0;
    for (let i = 0; i < qty; i++) {
      revenue += unitPrice(marketId, commodityId, stock, now);
      stock += 1;
    }
    const shipping = shippingPerUnit(state, commodityId, marketId) * qty;
    return { qty: qty, revenue: revenue, shipping: shipping, net: revenue - shipping };
  }


  /* ---------- Pengiriman (penjualan dan ekspor berwaktu) ---------- */

  function shipmentsOf(state) { return state.shipments || (state.shipments = []); }

  function shipSlots(state) {
    let n = C.shipSlotsBase;
    Object.keys(state.regions).forEach(function (rid) { n += infraLevel(state, rid, 'pelabuhan'); });
    return n;
  }

  // Slot kapal terpakai (penjualan lokal lewat truk tidak memakai slot).
  function slotsUsed(state) {
    return shipmentsOf(state).filter(function (x) { return !x.local; }).length;
  }

  // Lama kirim ke pasar dalam negeri, milidetik. 0 bila fitur dimatikan.
  function saleDuration(state, commodityId, marketId) {
    if (!C.saleTimeEnabled) return 0;
    const origin = D.commodities[commodityId].region;
    if (origin === marketId) {
      const cut = Math.min(0.5, C.saleTolSpeedup * infraLevel(state, origin, 'tol'));
      return Math.round(C.saleLocalSec * (1 - cut)) * 1000;
    }
    const ports = infraLevel(state, origin, 'pelabuhan') + infraLevel(state, marketId, 'pelabuhan');
    const cut = Math.min(0.5, C.salePortSpeedup * ports);
    const minutes = (C.saleSeaBaseMin + distanceKm(origin, marketId) * C.saleMinPerKm) * (1 - cut);
    return Math.round(minutes * 60) * 1000;
  }

  function enqueueShipment(state, x) {
    shipmentsOf(state).push(x);
    return x;
  }

  // Dipanggil dari sell(): barang sudah keluar gudang, kas menyusul saat tiba.
  function queueSale(state, commodityId, marketId, qty, q, dur, now) {
    const local = D.commodities[commodityId].region === marketId;
    if (!local && slotsUsed(state) >= shipSlots(state)) return null;
    return enqueueShipment(state, {
      id: 's' + now.toString(36) + shipmentsOf(state).length, kind: 'sale', local: local,
      commodity: commodityId, qty: qty, market: marketId,
      revenue: q.revenue, shipping: q.shipping, net: q.net, startedAt: now, endsAt: now + dur
    });
  }

  // Terima semua pengiriman yang waktunya habis (aman dipanggil belakangan, mis. setelah offline).
  function settleShipments(state, now) {
    const list = shipmentsOf(state);
    const done = list.filter(function (x) { return x.endsAt <= now; }).sort(function (a, b) { return a.endsAt - b.endsAt; });
    if (!done.length) return [];
    state.shipments = list.filter(function (x) { return x.endsAt > now; });
    done.forEach(function (x) {
      state.cash += x.net;
      state.totalEarned += x.net;
      if (x.kind === 'export') stat(state, 'exports', 1);
      if (x.net > (state.stats.bestSale || 0)) state.stats.bestSale = x.net;
    });
    return done;
  }

  /* ---------- Ekspor ---------- */

  function exportKey(id) { return 'export:' + id; }

  function exportDuration(state, commodityId, exportId) {
    const m = D.exportMarkets[exportId];
    const port = infraLevel(state, D.commodities[commodityId].region, 'pelabuhan');
    const cut = Math.min(0.3, C.exportPortSpeedup * port);
    return Math.round(m.baseHours * 3600 * (1 - cut)) * 1000;
  }

  function exportMaxQty(state, commodityId) {
    return C.exportBatchPerPort * infraLevel(state, D.commodities[commodityId].region, 'pelabuhan');
  }

  function exportShippingPerUnit(state, commodityId, exportId) {
    const c = D.commodities[commodityId], m = D.exportMarkets[exportId];
    const port = infraLevel(state, c.region, 'pelabuhan');
    const discount = Math.min(C.maxShippingDiscount, port * C.portDiscountPerLevel);
    const realRp = c.unitKg * m.km * C.seaFreightRpPerKgKm * (c.freightFactor || 1) * C.exportFreightFactor;
    return realRp / C.priceScale * (1 - discount);
  }

  function exportNormalPrice(commodityId, exportId) {
    const m = D.exportMarkets[exportId];
    return D.commodities[commodityId].basePrice * ((m.demand && m.demand[commodityId]) || m.mult);
  }

  function exportUnitPrice(commodityId, exportId, stock, now) {
    const depth = D.commodities[commodityId].marketDepth * C.exportDepthMult;
    const pressure = stock / (stock + depth);
    return exportNormalPrice(commodityId, exportId) * wave(exportKey(exportId), commodityId, now) *
      worldPriceMult(commodityId, now) * (1 - C.maxMarketDrop * pressure);
  }

  function quoteExport(state, commodityId, exportId, qty, now) {
    let stock = marketStock(state, exportKey(exportId), commodityId, now);
    let revenue = 0;
    for (let i = 0; i < qty; i++) {
      revenue += exportUnitPrice(commodityId, exportId, stock, now);
      stock += 1;
    }
    const shipping = exportShippingPerUnit(state, commodityId, exportId) * qty;
    return { qty: qty, revenue: revenue, shipping: shipping, net: revenue - shipping,
      durationMs: exportDuration(state, commodityId, exportId), maxQty: exportMaxQty(state, commodityId) };
  }

  // Kelas ekspor: 'bebas' | 'terbatas' | 'domestik'. Komoditas tanpa tanda dianggap bebas.
  function exportClassOf(commodityId) {
    const c = D.commodities[commodityId];
    return (c && c.exportClass) || 'bebas';
  }

  // Boleh diekspor sekarang? Mengembalikan { cls, ok, reason }. reason selalu menjelaskan cara membukanya.
  function exportStatus(state, commodityId) {
    const c = D.commodities[commodityId];
    if (!c) return { cls: 'bebas', ok: false, reason: 'Komoditas tidak dikenal.' };
    const cls = exportClassOf(commodityId);
    if (cls === 'domestik') {
      return { cls: cls, ok: false, reason: c.name + ' adalah kebutuhan dalam negeri dan tidak bisa diekspor. Jual ke pasar pulau lain (menu Pasar).' };
    }
    if (cls === 'terbatas') {
      const rule = c.exportRule || {};
      if (rule.needBuilding && buildingLevel(state, rule.needBuilding) < 1) {
        const b = D.buildings && D.buildings[rule.needBuilding];
        return { cls: cls, ok: false, reason: c.name + ' tidak boleh diekspor mentah. Bangun ' + (b ? b.name : rule.needBuilding) + ' dulu.' };
      }
    }
    return { cls: cls, ok: true, reason: '' };
  }

  // Wajib jual dalam negeri (DMO): bagian kiriman yang dipotong otomatis. exportQty = yang benar-benar berlayar.
  function exportPlan(commodityId, qty) {
    qty = Math.floor(qty);
    const rule = (exportClassOf(commodityId) === 'terbatas' && D.commodities[commodityId].exportRule) || {};
    const dmoQty = rule.quotaPct ? Math.floor(qty * rule.quotaPct) : 0;
    return { qty: qty, dmoQty: dmoQty, exportQty: qty - dmoQty };
  }

  function exportGoods(state, commodityId, exportId, qty, now) {
    qty = Math.floor(qty);
    const c = D.commodities[commodityId], m = D.exportMarkets && D.exportMarkets[exportId];
    if (!c || !m) return fail('Tujuan ekspor tidak dikenal.');
    const st = exportStatus(state, commodityId);
    if (!st.ok) return fail(st.reason);
    const port = infraLevel(state, c.region, 'pelabuhan');
    if (port < m.minPort) return fail('Ekspor ke ' + m.name + ' butuh Pelabuhan level ' + m.minPort + ' di ' + D.regions[c.region].name + '.');
    if (qty < 1) return fail('Tidak ada barang untuk diekspor.');
    if ((state.inventory[commodityId] || 0) < qty) return fail('Stok di gudang tidak cukup.');
    const max = exportMaxQty(state, commodityId);
    if (qty > max) return fail('Satu kapal hanya muat ' + max + ' satuan. Naikkan level pelabuhan untuk muatan lebih besar.');
    if (slotsUsed(state) >= shipSlots(state)) return fail('Semua kapal sedang berlayar (' + shipSlots(state) + '). Tunggu salah satu tiba atau naikkan pelabuhan.');

    const plan = exportPlan(commodityId, qty);
    if (plan.exportQty < 1) return fail('Setelah kuota dalam negeri (' + Math.round(plan.dmoQty / qty * 100) + '%) tidak ada yang tersisa untuk diekspor.');
    const q = quoteExport(state, commodityId, exportId, plan.exportQty, now);
    if (q.net <= 0) return fail('Ongkir lebih mahal dari hasil jual. Naikkan pelabuhan atau coba tujuan lain.');

    // Kuota dalam negeri (DMO): dibayar tunai di pasar wilayah asal, tanpa kapal.
    let dmoNet = 0;
    if (plan.dmoQty > 0) {
      const home = c.region;
      const dq = quoteSale(state, commodityId, home, plan.dmoQty, now);
      dmoNet = Math.max(0, dq.revenue);
      state.market[home] = state.market[home] || {};
      const hs = marketStock(state, home, commodityId, now);
      state.market[home][commodityId] = { stock: hs + plan.dmoQty, updatedAt: now };
      state.cash += dmoNet;
      state.totalEarned += dmoNet;
    }

    const key = exportKey(exportId);
    state.market[key] = state.market[key] || {};
    const stock = marketStock(state, key, commodityId, now);
    state.market[key][commodityId] = { stock: stock + plan.exportQty, updatedAt: now };
    state.inventory[commodityId] -= qty;
    enqueueShipment(state, {
      id: 'x' + now.toString(36) + shipmentsOf(state).length, kind: 'export', local: false,
      commodity: commodityId, qty: plan.exportQty, market: exportId,
      revenue: q.revenue, shipping: q.shipping, net: q.net, startedAt: now, endsAt: now + q.durationMs
    });
    stat(state, 'sold', qty);
    return { ok: true, qty: plan.exportQty, dmoQty: plan.dmoQty, dmoNet: dmoNet, net: q.net, revenue: q.revenue, shipping: q.shipping, queued: true, durationMs: q.durationMs };
  }

  function sell(state, commodityId, marketId, qty, now) {
    qty = Math.floor(qty);
    const ms = state.regions[marketId];
    if (!D.commodities[commodityId] || !ms) return fail('Pasar tidak dikenal.');
    if (!ms.unlocked) return fail('Buka wilayah ini dulu untuk berdagang di sana.');
    if (qty < 1) return fail('Tidak ada barang untuk dijual.');
    if ((state.inventory[commodityId] || 0) < qty) return fail('Stok di gudang tidak cukup.');

    const q = quoteSale(state, commodityId, marketId, qty, now);
    if (q.net <= 0) return fail('Harga terlalu rendah, penjualan akan rugi. Coba pasar lain.');

    const dur = saleDuration(state, commodityId, marketId);
    let shipment = null;
    if (dur > 0) {
      shipment = queueSale(state, commodityId, marketId, qty, q, dur, now);
      if (!shipment) return { ok: false, slots: true, reason: 'Semua kapal sedang berlayar (' + shipSlots(state) + '). Tunggu salah satu tiba atau naikkan pelabuhan.' };
    }

    const stock = marketStock(state, marketId, commodityId, now);
    state.market[marketId][commodityId] = { stock: stock + qty, updatedAt: now };
    state.inventory[commodityId] -= qty;
    stat(state, 'sales', 1);
    stat(state, 'sold', qty);
    if (shipment) {
      return { ok: true, qty: qty, revenue: q.revenue, shipping: q.shipping, net: q.net, queued: true, durationMs: dur };
    }
    state.cash += q.net;
    state.totalEarned += q.net;
    if (q.net > (state.stats.bestSale || 0)) state.stats.bestSale = q.net;
    return { ok: true, qty: qty, revenue: q.revenue, shipping: q.shipping, net: q.net };
  }

  // Jual SEMUA isi gudang
  // ke satu pasar sekaligus. Komoditas yang akan rugi dilewati (dicatat di skipped).
  function sellAll(state, marketId, now) {
    const ms = state.regions[marketId];
    if (!ms) return fail('Pasar tidak dikenal.');
    if (!ms.unlocked) return fail('Buka wilayah ini dulu untuk berdagang di sana.');
    const items = [], skipped = [];
    let net = 0, qty = 0, slotFull = null;
    Object.keys(D.commodities).forEach(function (cid) {
      const have = Math.floor(state.inventory[cid] || 0);
      if (have < 1) return;
      const r = sell(state, cid, marketId, have, now);
      if (r.ok) { items.push({ commodity: cid, qty: r.qty, net: r.net, queued: !!r.queued, durationMs: r.durationMs }); net += r.net; qty += r.qty; }
      else { skipped.push(cid); if (r.slots) slotFull = r.reason; }
    });
    if (!items.length && slotFull) return fail(slotFull);
    if (!items.length) {
      return fail(skipped.length ? 'Harga di pasar ini terlalu rendah, semua penjualan akan rugi. Coba pasar lain.'
        : 'Gudang kosong, tidak ada yang bisa dijual.');
    }
    return { ok: true, items: items, skipped: skipped, net: net, qty: qty, queued: items.some(function (i) { return i.queued; }), durationMs: items.reduce(function (m, i) { return Math.max(m, i.durationMs || 0); }, 0) };
  }

  // Perkiraan hasil bersih bila seluruh gudang dijual ke satu pasar (tanpa mengubah state).
  function quoteSellAll(state, marketId, now) {
    let net = 0, qty = 0;
    Object.keys(D.commodities).forEach(function (cid) {
      const have = Math.floor(state.inventory[cid] || 0);
      if (have < 1) return;
      const q = quoteSale(state, cid, marketId, have, now);
      if (q.net > 0) { net += q.net; qty += have; }
    });
    return { net: net, qty: qty };
  }

  // Deret harga untuk grafik mini: dari backMin menit lalu sampai fwdMin menit ke depan.
  // Memakai rumus harga yang sama dengan pasar (gelombang, musim, peristiwa, tekanan jual yang meluruh).
  function priceSeries(state, marketId, commodityId, now, backMin, fwdMin, steps) {
    const out = [];
    const span = (backMin + fwdMin) * 60000;
    for (let i = 0; i <= steps; i++) {
      const t = now - backMin * 60000 + span * i / steps;
      out.push({ t: t, price: unitPrice(marketId, commodityId, marketStock(state, marketId, commodityId, t), t) });
    }
    return out;
  }

  // Isyarat harga: bagus (>= 8% di atas normal), rendah (<= 8% di bawah), atau normal.
  // peakInMin = menit sampai puncak dalam 30 menit ke depan bila lebih tinggi >= 5% dari sekarang.
  function priceSignal(state, marketId, commodityId, now) {
    const cur = currentPrice(state, marketId, commodityId, now);
    const ratio = cur / normalPrice(marketId, commodityId);
    const id = ratio >= 1.08 ? 'bagus' : (ratio <= 0.92 ? 'rendah' : 'normal');
    let peakInMin = null, peak = cur;
    priceSeries(state, marketId, commodityId, now, 0, 30, 30).forEach(function (p) {
      if (p.price > peak) { peak = p.price; peakInMin = Math.round((p.t - now) / 60000); }
    });
    if (peakInMin !== null && peak < cur * 1.05) peakInMin = null;
    return { id: id, ratio: ratio, price: cur, peakInMin: peakInMin, peakPrice: peak };
  }

  // Pasar terbuka dengan harga bersih per unit tertinggi untuk komoditas ini.
  function bestMarket(state, commodityId, now) {
    let best = null;
    Object.keys(state.regions).forEach(function (rid) {
      if (!state.regions[rid].unlocked) return;
      const p = netUnitPrice(state, commodityId, rid, now);
      if (!best || p > best.price) best = { regionId: rid, price: p };
    });
    return best;
  }

  /* ---------- Skor peradaban ---------- */

  function score(state) {
    let s = 0;
    Object.keys(state.buildings).forEach(function (id) { s += state.buildings[id].level * 10; });
    Object.keys(state.regions).forEach(function (rid) {
      const r = state.regions[rid];
      if (r.unlocked && !D.regions[rid].start) s += 100;
      s += ((r.infra.tol || 0) + (r.infra.pelabuhan || 0)) * 25;
    });
    s += Math.floor(state.totalEarned / 1000);
    return s;
  }

  function rank(scoreValue) {
    let current = D.ranks[0];
    let next = null;
    for (let i = 0; i < D.ranks.length; i++) {
      if (scoreValue >= D.ranks[i].min) { current = D.ranks[i]; next = D.ranks[i + 1] || null; }
    }
    return { current: current, next: next };
  }

  NT.economy = {
    distanceKm: distanceKm,
    worldProdMult: worldProdMult,
    worldPriceMult: worldPriceMult,
    buildingLevel: buildingLevel,
    infraLevel: infraLevel,
    productionRate: productionRate,
    capacity: capacity,
    pending: pending,
    collect: collect,
    collectAll: collectAll,
    totalPendingValue: totalPendingValue,
    buildingCost: buildingCost,
    infraCost: infraCost,
    jobFor: jobFor,
    buildDuration: buildDuration,
    infraDuration: infraDuration,
    settle: settle,
    speedup: speedup,
    speedupCost: speedupCost,
    incomePerMin: incomePerMin,
    nextGoal: nextGoal,
    cheapestUpgrade: cheapestUpgrade,
    upgradeBuilding: upgradeBuilding,
    upgradeInfra: upgradeInfra,
    unlockRegion: unlockRegion,
    marketStock: marketStock,
    normalPrice: normalPrice,
    currentPrice: currentPrice,
    shippingPerUnit: shippingPerUnit,
    netUnitPrice: netUnitPrice,
    quoteSale: quoteSale,
    sell: sell,
    saleDuration: saleDuration,
    settleShipments: settleShipments,
    shipSlots: shipSlots,
    slotsUsed: slotsUsed,
    exportGoods: exportGoods,
    exportStatus: exportStatus,
    exportClassOf: exportClassOf,
    exportPlan: exportPlan,
    quoteExport: quoteExport,
    exportDuration: exportDuration,
    exportMaxQty: exportMaxQty,
    sellAll: sellAll,
    quoteSellAll: quoteSellAll,
    priceSeries: priceSeries,
    priceSignal: priceSignal,
    bestMarket: bestMarket,
    score: score,
    rank: rank,
    _fmt: fmt
  };
})((window.NT = window.NT || {}));
